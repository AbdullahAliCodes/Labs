import java.util.*;

public class Program {
	

		  public static void main(String[] args) {
		    Dog[] dogs = new Dog[5]; // Array to store 5 Dog objects
		    Scanner in = new Scanner(System.in);

		    for (int i = 0; i < dogs.length; i++) {
		      
		      String line = in.nextLine();
		      String[] parts = line.split(" "); // Split input line by space
		      String name = parts[0];
		      int age = Integer.parseInt(parts[1]); // Convert age string to integer
		      dogs[i] = new Dog(name, age);
		    }

		    
		    for (Dog dog : dogs) {
		      dog.bark();
		    }
		  }
		
}
