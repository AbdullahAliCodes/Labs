import java.util.*;

public class Program {
	
	    public static void main(String[] args) {
	        
	        Scanner in = new Scanner(System.in);

	        // Declare an array to hold 10 numbers
	        int[] numbers = new int[10];

	        // Read 10 numbers into the array using a for loop
	        for (int i = 0; i < 10; i++) {
	            
	            numbers[i] = in.nextInt();
	        }

	        // Prompt for the index and ensure valid input
	        int index;
	        do {
	            index = in.nextInt();
	        } while (index < 0 || index >= 10);

	        // Print the number at the specified index
	        System.out.println( numbers[index]);

	       
	    }
	

}
