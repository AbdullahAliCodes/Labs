import java.util.*;

public class Program {
	
	    public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);

	        // Read array size
	        int arraySize = in.nextInt();

	        // Create array using an integer array for efficiency
	        int[] numbersArray = new int[arraySize];

	        // Read elements into the array using a for loop
	        for (int i = 0; i < arraySize; i++) {
	            numbersArray[i] = in.nextInt();
	        }

	        // Read index for lookup
	        int index = in.nextInt();

	        
	            // Access and print the element at the specified index
	            int numberToPrint = numbersArray[index];
	            System.out.println( numberToPrint);
	        

	        
	    }
	

}
