import java.util.*;

public class Program {
	

	  public static void main(String[] args) {
	    Scanner in = new Scanner(System.in);
	    
	    final int numStrings = 10; // Number of strings to read

	    String[] strings = new String[numStrings];

	    // Read the strings from the user
	    for (int i = 0; i < numStrings; i++) {
	      strings[i] = in.nextLine();
	    }

	    // Print the strings in reverse order
	    for (int i = numStrings - 1; i >= 0; i--) {
	      System.out.println(strings[i]);
	    }

	    
	  }
	

}
