import java.util.*;

public class Program {
	

	    public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);  // Create Scanner object

	        int arraySize = in.nextInt();  // Read array size

	        int[] numbers = new int[arraySize];  // Create array of the required size

	       
	        for (int i = 0; i < arraySize; i++) {
	            
	            numbers[i] = in.nextInt();  // Read and store numbers
	        }

	        
	        for (int i = arraySize - 1; i >= 0; i--) {
	            System.out.print(numbers[i] + " ");  // Print numbers in reverse order
	        }

	        
	    }
	

}
