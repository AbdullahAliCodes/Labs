public class Program{
public static void main(String args[]){
double pi=3.1415, area, volume;
int r=5;
area = pi * r * r;
double height = 24;
volume = height * area;
System.out.println("The volume is : " + volume);
}
}